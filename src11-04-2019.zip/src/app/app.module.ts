import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { AppComponent } from './app.component';
import { QuizComponent } from './quiz/quiz.component';
import { QuestionComponent } from './question/question.component';
import { BlogComponent } from './blog/blog.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { HomeComponent } from './home/home.component';
import { UserService } from './_service/user.service';
import { QuestionService } from './_service/question.service';
import { QuizService } from './_service/quiz.service';
import { SpinnerComponent } from './spinner/spinner.component';
import {ToastrModule} from 'ngx-toastr';
import { ToastService } from './_service/toast.service';
import { ToastComponent } from './toast/toast.component';
import { AdminComponent } from './admin/admin.component';
import { appRoutingModule } from './app-routing';

@NgModule({
  declarations: [
    AppComponent,
    QuizComponent,
    QuestionComponent,
    BlogComponent,
    LoginComponent,
    RegisterComponent,
    NavMenuComponent,
    HomeComponent,
    SpinnerComponent,
    ToastComponent,
    AdminComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    appRoutingModule,
    HttpClientModule,
    FormsModule,
    ToastrModule.forRoot(),
    ReactiveFormsModule,
    // RouterModule.forRoot([
    //     { path: 'quiz', component: QuizComponent },
    //     { path: 'question', component: QuestionComponent },
    //     { path: 'login', component: LoginComponent },
    //     { path: 'register', component: RegisterComponent },
    //     { path: 'home', component: HomeComponent },
    // ]),
    NgbModule
  ],
  providers: [UserService, QuizService, QuestionService,ToastService],
  bootstrap: [AppComponent]
})
export class AppModule { }
