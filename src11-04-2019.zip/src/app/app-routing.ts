import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './_helpers/auth.guard';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { Role } from './_model/role';
import { AdminComponent } from './admin/admin.component';
import { QuizComponent } from './quiz/quiz.component';
import { BlogComponent } from './blog/blog.component';
import { QuestionComponent } from './question/question.component';
import { RegisterComponent } from './register/register.component';

const routes: Routes = [
  {
      path: '',
      component: HomeComponent,
      canActivate: [AuthGuard]
  },
  {
      path: 'admin',
      component: AdminComponent,
      canActivate: [AuthGuard],
      data: { roles: [Role.Admin] }
  },
  {
      path: 'blog',
      component: BlogComponent
  },
  {
      path: 'question',
      component: QuestionComponent
  },
  {
      path: 'quiz',
      component: QuizComponent
  },
  {
      path: 'quiz',
      component: QuizComponent
  },
  {
      path: 'quiz',
      component: QuizComponent
  },
  {
      path: 'register',
      component: RegisterComponent
  },
  {
      path: 'login',
      component: LoginComponent
  },
  // otherwise redirect to home
  { path: '**', redirectTo: '' }
];

export const appRoutingModule = RouterModule.forRoot(routes);
