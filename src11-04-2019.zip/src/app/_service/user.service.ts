import { Injectable } from '@angular/core';
import { BaseService } from './base.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable()

export class UserService extends BaseService {

  baseUrl: string;
  headers: any = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
  // Observable navItem source
  private authNavStatusSource = new BehaviorSubject<boolean>(false);
  // Observable navItem stream
  authNavStatus$ = this.authNavStatusSource.asObservable();

  private loggedIn = false;

  constructor(private http: HttpClient) {
    super();
    this.loggedIn = !!localStorage.getItem('auth_token');
    // ?? not sure if this the best way to broadcast the status but seems to resolve issue on page refresh where auth status is lost in
    // header component resulting in authed user nav links disappearing despite the fact user is still logged in
    this.authNavStatusSource.next(this.loggedIn);
    this.baseUrl = environment._apiURI;
  }

  getUserDetails()
  {
   return localStorage.getItem('auth_token');
  }

  getUser()
  {
   return localStorage.getItem('auth_token');
  }

  register(email: string, password: string): Observable<boolean> {
    const body = JSON.stringify({ email, password });
    return this.http.post(this.baseUrl + '/Auth/register', body, this.headers)
      .pipe(map(res => true))
      .catch(this.handleError);
  }

  login(userName, password) {
    const body = JSON.stringify({ userName, password });
    return this.http
      .post(
        this.baseUrl + '/auth/login',
        body, this.headers
      );
  }

  logout() {
    localStorage.removeItem('auth_token');
    this.loggedIn = false;
    this.authNavStatusSource.next(false);
  }

  isLoggedIn() {
    return this.loggedIn;
  }
}
