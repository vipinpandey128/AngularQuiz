export interface UserRegistration {
  email: string;
  password: string;
}
