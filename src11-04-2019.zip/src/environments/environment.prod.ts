export const environment = {
    production: true,
    _apiURI: 'http://api.webscrackers.com/api'
  };